package testcases;

import org.testng.annotations.DataProvider;

import base.ProjectSpecificMethod;
import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;


@CucumberOptions(features={"src/main/java/features"},
glue="pages",
publish=true)
//tags="not @Smoke")
public class RunnerCucumber extends ProjectSpecificMethod {
	@DataProvider()
	public Object[][] scenarios() {
		return super.scenarios();
	}

}
