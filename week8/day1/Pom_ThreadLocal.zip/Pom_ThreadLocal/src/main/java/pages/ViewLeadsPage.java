package pages;

import org.openqa.selenium.By;

import base.ProjectSpecificMethod;
import io.cucumber.java.en.Then;

public class ViewLeadsPage extends ProjectSpecificMethod {
	
	
	@Then("ViewLeads page is displayed")
	public ViewLeadsPage verifyLeads() {
		 String text = getDriver().findElement(By.id("viewLead_firstName_sp")).getText();
		 if (text.contains("saran")) {
			System.out.println("view leads page is displayed");
		} else {
			System.out.println("view leads page is not displayed");
		}
		return this; 
		 
	}
	
}
