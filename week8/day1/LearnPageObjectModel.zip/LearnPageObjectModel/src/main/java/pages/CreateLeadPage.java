package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethod;

public class CreateLeadPage extends ProjectSpecificMethod {
	
	public CreateLeadPage(ChromeDriver driver) {
		this.driver=driver;
	}
	public CreateLeadPage enterCName() {
		driver.findElement(By.id("createLeadForm_companyName")).sendKeys("Testleaf");
		return this;
	}
	public CreateLeadPage enterFName() {
		driver.findElement(By.id("createLeadForm_firstName")).sendKeys("Saran");
		return this;
	}	
	public CreateLeadPage enterLName() {
		driver.findElement(By.id("createLeadForm_lastName")).sendKeys("S");
		return this;
	}
	public ViewLeadsPage clickCLLink() {
		driver.findElement(By.name("submitButton")).click();
		return new ViewLeadsPage(driver);
	}

}
