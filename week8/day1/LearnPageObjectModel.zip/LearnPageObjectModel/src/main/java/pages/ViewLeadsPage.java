package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethod;

public class ViewLeadsPage extends ProjectSpecificMethod {
	
	public ViewLeadsPage(ChromeDriver driver) {
		this.driver=driver;
	}

	public ViewLeadsPage verifyLeads() {
		 String text = driver.findElement(By.id("viewLead_firstName_sp")).getText();
		 if (text.contains("saran")) {
			System.out.println("view leads page is displayed");
		} else {
			System.out.println("view leads page is not displayed");
		}
		return this; 
		 
	}
	
}
