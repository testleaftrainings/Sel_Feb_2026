package testcases;

import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;

public class RunCL extends ProjectSpecificMethod {
	@Test
	public void runCL() {
		System.out.println("testClass:"+driver);
		LoginPage lp=new LoginPage(driver);
		lp.enterUname().enterPwd().clickLogin().clickCrmsfa().clickLeads().clickCreateLead()
		.enterCName().enterFName().enterLName().clickCLLink().verifyLeads();
	}
}
