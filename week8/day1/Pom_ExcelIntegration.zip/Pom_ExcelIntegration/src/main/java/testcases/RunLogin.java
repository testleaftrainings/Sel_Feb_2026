package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;

public class RunLogin extends ProjectSpecificMethod {
	@BeforeTest
	public void setValues() {
		excelFileName="Login";
	}
	@Test(dataProvider="fetchData")
	public void runLT(String uName,String pwd) {
		System.out.println("testClass:"+driver);
		LoginPage lp=new LoginPage(driver);
		lp.enterUname(uName).enterPwd(pwd).clickLogin().clickCrmsfa();
	}

}
