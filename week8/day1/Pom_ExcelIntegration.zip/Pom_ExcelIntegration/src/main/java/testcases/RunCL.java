package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;

public class RunCL extends ProjectSpecificMethod {
	@BeforeTest
	public void setValues() {
		excelFileName="CreateLead";
	}
	@Test(dataProvider="fetchData")
	public void runCL(String uName,String pwd,String cName,String fName,String lName) {
		System.out.println("testClass:"+driver);
		LoginPage lp=new LoginPage(driver);
		lp.enterUname(uName).enterPwd(pwd).clickLogin().clickCrmsfa().clickLeads().clickCreateLead()
		.enterCName(cName).enterFName(fName).enterLName(lName).clickCLLink().verifyLeads();
	}
}
