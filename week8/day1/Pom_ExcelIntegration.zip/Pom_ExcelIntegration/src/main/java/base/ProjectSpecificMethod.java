package base;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;

import utils.ReadExcelIntegration;

public class ProjectSpecificMethod {
public ChromeDriver driver;
public String excelFileName;
	
	@BeforeMethod
	public void preConditions() {
		driver=new ChromeDriver();
		System.out.println("beforeMethod:"+driver);
		driver.get("http://leaftaps.com/opentaps/control/main");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
	}
	@AfterMethod
	public void postConditions() {
		driver.close();
	}
	@DataProvider(name="fetchData",parallel=true)
	public String[][] sendData() throws IOException {
		return ReadExcelIntegration.readExcel(excelFileName);
	}
}
