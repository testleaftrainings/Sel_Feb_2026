package pages;

import org.openqa.selenium.By;

import base.ProjectSpecificMethod;
import io.cucumber.java.en.And;
import io.cucumber.java.en.When;

public class CreateLeadPage extends ProjectSpecificMethod {
	
	@And("Enter the Company name as(.*)$")
	public CreateLeadPage enterCName(String cName) {
		driver.findElement(By.id("createLeadForm_companyName")).sendKeys(cName);
		return this;
	}
	@And("Enter firstname as(.*)$")
	public CreateLeadPage enterFName(String fName) {
		driver.findElement(By.id("createLeadForm_firstName")).sendKeys(fName);
		return this;
	}	
	@And("Enter LastName as(.*)$")
	public CreateLeadPage enterLName(String lName) {
		driver.findElement(By.id("createLeadForm_lastName")).sendKeys(lName);
		return this;
	}
	@When("click on CreateLead Buttons")
	public ViewLeadsPage clickCLLink() {
		driver.findElement(By.name("submitButton")).click();
		return new ViewLeadsPage();
	}

}
