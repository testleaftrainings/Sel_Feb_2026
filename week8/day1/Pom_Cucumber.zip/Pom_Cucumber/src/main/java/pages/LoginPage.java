package pages;

import org.openqa.selenium.By;

import base.ProjectSpecificMethod;
import io.cucumber.java.en.When;

public class LoginPage extends ProjectSpecificMethod{
	
	
	@When("Enter the username as {string}")
	public LoginPage enterUname(String uName) {
		driver.findElement(By.id("username")).sendKeys(uName);
		
		return this;
}
	@When("Enter the password as {string}")
	public LoginPage enterPwd(String pwd) {
		driver.findElement(By.id("password")).sendKeys(pwd);
		return this;
	}
	@When("Click on Login button")
	public WelcomePage clickLogin() {
		driver.findElement(By.className("decorativeSubmit")).click();
		return new WelcomePage();
	}
}
