package pages;

import org.openqa.selenium.By;

import base.ProjectSpecificMethod;
import io.cucumber.java.en.When;

public class WelcomePage extends ProjectSpecificMethod {
	
	
	@When("Click on crmsfa button")
	public HomePage clickCrmsfa() {
		driver.findElement(By.linkText("CRM/SFA")).click();
		return new HomePage();
	}

}
