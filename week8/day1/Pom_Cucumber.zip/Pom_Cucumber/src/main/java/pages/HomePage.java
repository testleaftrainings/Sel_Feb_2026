package pages;

import org.openqa.selenium.By;

import base.ProjectSpecificMethod;
import io.cucumber.java.en.When;

public class HomePage extends ProjectSpecificMethod {
	
	
	@When("Click on Leads link")
	public MyLeadsPage clickLeads()
	{
		driver.findElement(By.linkText("Leads")).click();
		return new MyLeadsPage();
	}
}
